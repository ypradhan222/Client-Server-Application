//Author: Yogen Pradhan
//Implementation of post fix calculator

package assignment.services.calc;
import java.util.*;
import java.lang.*;
import java.io.*;
//import assignment.utility.*;

public class PfCalculator{
	static double a, b;
	public static boolean operator(String s){
	return (s.equals("*") || s.equals("%") || s.equals("^") || s.equals("+") ||s.equals("-") || s.equals("/"))	;
	}
    public static double evaluate(Queue<String> q) throws IllegalArgumentException,EmptyStackException,ArithmeticException {
	  Stack<String> stack = new Stack<String>();
	 // String s;
	  //int A,B;
	  double x =0;
	  try{
	    //for(Iterator<String> i= q.iterator();i.hasNext();){
		//  s = i.next();
	String str = q.poll();
			// stack.push(s);
		  //else
            //if(!stack.empty()){
		while(str!=null){
				if(PfCalculator.operator(str)){
					a= 0;
					b =0;
					a = Double.parseDouble(stack.pop()) ;
					b = Double.parseDouble(stack.pop()) ;
				
				//catch(NumberFormatException n){
				//	throw new NumberFormatException("Invalid Input!!! ");
				//}
				if(str.equals("+"))
					{stack.push(String.valueOf(a + b ));}
				else if(str.equals("-"))
					{stack.push(String.valueOf(b - a ));}
				else if(str.equals("*"))
					{stack.push(String.valueOf(a * b ));}
				else if(str.equals("/")){
					if(b==0)
					System.out.println("cannot divide!!");
					stack.push(String.valueOf(b / a ));
					}
				else if(str.equals("%"))
					{stack.push(String.valueOf((double)((int)b % (int)a)));}
				     else if(str.equals("^"))
				 	{stack.push(String.valueOf(Math.pow(b,a)));}
			}else
			{
			Double.parseDouble(str);
			stack.push(str);				
			}
			str = q.poll();	
			}    			  
		}
 		catch(EmptyStackException e){
		  throw new IllegalArgumentException("Invalid Input!!");
	  }
 		if((stack.size())!=1)
			 throw new ArithmeticException("Abundance");
	
	x = Double.parseDouble(stack.pop());
	return x;
	  }

	public static void driver(BufferedReader in, PrintWriter out) throws IOException {
	String ips = "",x;
	String y="";
	  //do{
		out.println("Please enter the inputs :: \n-EOF-");
		ips = in.readLine();	       
		//ips = Validator.getString("Please enter the inputs :: ");
		StringTokenizer s = new StringTokenizer(ips);
		Queue<String> q = new LinkedList<String>();
		
		while(s.hasMoreTokens()){
		 q.add(s.nextToken());
		 }
		if(q.size()>1){
		double result =0;
		 //PfCalculator obj = new PfCalculator();
		 
		 try{
		ips = "n";		   
		result = evaluate(q);
		   //if(x != null)
		   //System.out.println(x);
		   //else 
		    //System.out.println("Invalid Input!!");
		 }
		catch(NumberFormatException ex){		
		//System.out.println("Invalid literal!!");
		y+="Invalid literal!!";		
		out.println(y);
		ips = "yes";
		}
		 catch(IllegalArgumentException e){
		   e.printStackTrace();
		 }
		 
		catch(NullPointerException ex){
		y="";		
		y+="Nothing Entered";		
		//System.out.println("Nothing Entered");
		out.println(y);
		ips = "yes";			
		}
		
		catch(ArithmeticException ex){
		y="";
		y+="Extra literals";
		out.println(y);
		//System.out.println("Extra literals");		
		}
		catch(Exception n){
		  out.println(n);
		}
		if(!ips.equalsIgnoreCase("y"))
		{
		y="";
		y+="\n\tThe result of given postfix expression : ";
		out.println(y);
		out.println(result);
		//System.out.println("\n\tThe result of given postfix expression : "+result);
		//ips = Validator.getString("\nDo you want to continue(Y/N) :: ");
		
		//out.println("\nDo you want to continue(Y/N) :: \n-EOF-");
		//ips = in.readLine();
		}
		}
	  	else{
		y="";
		y+="Have atleast two or more operands!!";
		out.println(y);
		//System.out.println("Have atleast two or more operands!!");	
		ips = "yes \n";
				
		}
		 
	//  }
	 // while (ips.equalsIgnoreCase("y"));	

	out.println("-EOF-");
	}
	  
	
}



