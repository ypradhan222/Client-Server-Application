package assignment.services.cowsandbulls;
import java.util.Scanner;
import assignment.utility.*;
import java.io.*;
public class Bulls {
	static String  ips;
	private static String chosenNum = "";
	private static void printWelcomeMessage(BufferedReader in,PrintWriter out) {
		String i="";
		i+="Welcome to the game of BULLS and COWS.\n";
		i+="The objective in this game is for you to guess a 4-digit number.\n";
		i+="The computer responds with how close your guess is to the target.\n";
		i+="BULLS = # common digits with exact matches.\n";
		i+="COWS = # common digits in wrong position.\n\n";
		out.println(i);

	}
	//Generate a 4 digit number with no repeated digits
	private static String produceRandomTarget() {
		int randomNumber = 1000 + ((int) (Math.random() * 10000) % 9000);
		chosenNum = Integer.toString(randomNumber);
		while (hasRepeatingDigits(chosenNum)) {
			produceRandomTarget();
		}
		return chosenNum;
	}
	//checks whether the number has repeated digits
	private static boolean hasRepeatingDigits(String num) {
		for (int i = 0; i < num.length() - 1; i++) {
			for (int j = i + 1; j < num.length(); j++) {
				if (num.charAt(i) == num.charAt(j)) {
					return true;
				}
			}
		}
		return false;
	}
	private static boolean containsNonDigits(String num) {
		if (!num.matches("^[0-9]+$")) {
			return true;
		}
		return false;
	}
	private static int computeBulls(String num1, String num2) {
		int bullCounter = 0;
		for (int i = 0; i < num1.length(); i++) {
			if (num1.charAt(i) == num2.charAt(i)) {
				bullCounter++;
			}
		}
		return bullCounter; //Returns common digit in exact positions
	}
	private static int computeCows(String num1, String num2) {
		int cowsCounter = 0;
		for (int i = 0; i < num1.length(); i++) {
			for (int j = 0; j < num2.length(); j++) {
				if (i != j) {
					if (num1.charAt(i) == num2.charAt(j)) {
						cowsCounter++;
					}
				}
			}
		}
		return cowsCounter;  //returns common digits in wrong position
	}
	public static void start(BufferedReader in,PrintWriter out) throws IOException{
		//do{		
		//Scanner sc = new Scanner(System.in);
		printWelcomeMessage(in,out);
		produceRandomTarget();
		int bulls = 0;
		int cows = 0;
		int guesses = 1;
		
		boolean notFound = true;
		while (notFound) {
			String y="";
			y+="Enter guess number " ;
			out.print(y);
			out.print(guesses);
			out.println(":");
			out.println("\n-EOF-");
			//String guessedNumber = sc.nextLine();
			String guessedNumber=in.readLine();
			bulls = computeBulls(guessedNumber, chosenNum);
			cows = computeCows(guessedNumber, chosenNum);
			//Play game until 10 tries
			if (guesses >= 10) {
				 y="";
				y+="Bulls =  \tCows = ";
				out.print(y);
				out.print(bulls);
				out.print(cows);
				out.println("-EOF-");
				//y="";
				//y+="\tCows =";
				//out.println(y);
				//out.println(cows);
				//sout.println("\n-EOF-");
				//y="";
				y+="Sorry! You ran out of guesses.\n";
				y+="The correct number was: ";
				out.print(y);
				out.println(chosenNum);
				out.println("\n-EOF-");
				notFound = false;
			} else if (hasRepeatingDigits(guessedNumber)) {
				y="";
				y+="Your guess should not contain repeating digits.";
				out.println(y);
			} else if (guessedNumber.length() != 4) {
				y="";
				y+="Your guess should contain 4 symbols (Digits)";
										 			  	  	out.println(y);
			} else if (containsNonDigits(guessedNumber)) {
				y="";
				y+="Your guess should not contain non-digits.";
				out.println(y);
			} else if (bulls == 4) {
				y="";
				y+="Bulls = ";
				out.println(y);
				out.println(bulls);
				//y="";
				y+="\tCows";
				out.println(y);
				out.println(cows);
				//System.out.println("Bulls = " + bulls + "\tCows = " + cows);
				y="";
				y+="Congratulations! You won with" ;
				out.println(y);
				  	   out.println(guesses);				
				//System.out.println("Congratulations! You won with " + guesses + " guesses.");
				y+="guesses";
				out.println(y);
				notFound = false;
			} else if (!hasRepeatingDigits(guessedNumber) && !containsNonDigits(guessedNumber)) {
				y="";
				y+="Bulls = ";
				out.println(y);
				out.println(bulls);
				y="";
				y+="\tCows";
				//System.out.println("Bulls = " + bulls + "\tCows = " + cows);
				guesses++;
			}
		}
		in.close();
		out.close();
		//sc.close();
		//ips = Validator.getString("Do you want to continue dear(Y/N) ::  ");
		
	//}while(ips.equalsIgnoreCase("y"));
	
	}


}
