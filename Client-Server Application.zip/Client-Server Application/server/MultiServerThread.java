package assignment.server;
import java.util.*;
import java.net.*;
import java.io.*;
import assignment.services.calc.*;
import assignment.services.cowsandbulls.*;
import assignment.services.sudoku.*;

public class MultiServerThread extends Thread  {
    private Socket socket = null;


    public MultiServerThread(Socket socket) {
	super("MultiServerThread");
	this.socket = socket;
    }

    public void run(){
	Server.addMe();
	System.out.println("Now connected to: "+socket.getInetAddress());
	try {
	    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
	    BufferedReader in = new BufferedReader(
				    new InputStreamReader(socket.getInputStream()));

	    String inp, outp="--";
	    String output = "";
	        output += "\nHello dear client,Welcome to Yoyo's Server.\n";
		output += "\tThe following are the services for you dear :: \n";
                output += "\n1.PfCalculator\t\n2. Cows and Bulls\t\n3.Sudoku";
                output += "\nPlease choose an option :: \n-EOF-";

		out.println(output);


	    while ((inp = in.readLine()) != null) {
                        System.out.println(inp);
		
			outp = processInput(inp,in,out);
			if (outp.equals("thank you and good bye")){
			    out.println("thank you and good bye");
			    out.close();
			    in.close();
			    socket.close();
			    break;
			}
		}
	} catch (IOException e) {
	    e.printStackTrace();
	}finally{
		try{
		    socket.close();
		    Server.removeMe();
		}catch(Exception e){System.out.println("Problem while closing socket..."+e);}
	}
  }
    private String processInput(String inp,BufferedReader in, PrintWriter out) {
		String ch = "";
		if(inp.equals("bye"))
			return "thank you and good bye";



                 //String output = "";
		try{             	
		do{
			if(inp.startsWith("1")) {
               PfCalculator.driver(in,out);
			   
		}else if(inp.startsWith("2")){
			Bulls.start(in,out);
			
		}else if(inp.startsWith("3")){
			Sudoku.start(in,out);
			
		}
		String op = "";
		op += "Do you want to continue(y/n): \n-EOF-";
                 out.println(op);
                 ch = in.readLine();
                 } while((ch.equals("Y"))||(ch.equals("y")));
                 
		out.println("-EOF-");
                
		}catch(IOException err){err.printStackTrace();}
     
		return ch;           
   }                 
}
 
