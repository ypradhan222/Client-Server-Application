package assignment.server;
import java.net.*;
import java.io.*;
import assignment.utility.*;
public class Server{
    private static int noOfClients = 0;

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        boolean listening = true;

        try {
            serverSocket = new ServerSocket(3000);
	System.out.println("Server started..\n");
	System.out.println("Waiting for clients to join...");
        } catch (IOException e) {
            System.err.println("Could not listen on port: 3000.");
            System.exit(-1);
        }

        while (listening)
            new MultiServerThread(serverSocket.accept()).start();

        serverSocket.close();
    }

    public static void addMe() {
        noOfClients++;
        System.out.println("Current no. of clients connected: " + noOfClients);
    }

    public static void removeMe() {
        noOfClients--;
        System.out.println("Current no. of clients connected: " + noOfClients);
    }
}
