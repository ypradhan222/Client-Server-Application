package assignment.utility;

import java.util.Scanner;
public class Validator{
  public static String getString(Scanner sc, String cause){
    System.out.println(cause);
	String s = sc.next();          //Reading the entry from the user
	sc.nextLine();
	return s;
  
  }
  public static String getString(String cause){
    Scanner sc = new Scanner(System.in);
	System.out.println(cause);
	String s = sc.nextLine();
    return s;
  }
  public static int getInt(Scanner sc, String cause){
    int i=0;
	boolean isValid = false;
	while(isValid == false){
	  System.out.println(cause);
	  if(sc.hasNextInt()){
	     i = sc.nextInt();
		 isValid = true;
	  }
	  else {
	    System.out.println("Error !! Invalid value :: TRY AGAIN");
	  }
	  sc.nextLine();
	}
      return i;
  
  }
  public static int getInt(String cause){
     Scanner sc = new Scanner(System.in);
	 int i=0;
	 boolean isValid = false;
	 while(isValid == false){
	  System.out.println(cause);
	  if(sc.hasNextInt()){
	     i = sc.nextInt();
		 isValid = true;
	  }
	  else{
	    System.out.println("Error !! Invalid value :: TRY AGAIN");
	  }
	  sc.nextLine();
  }
     return i;
}
public static int getInt(Scanner sc,String cause, int min, int max){
     int i=0;
	 boolean isValid = false;
	 while(isValid == false){
	   i = getInt(sc, cause);
	   if(i <= min)
	   System.out.println("Error !! Number must be greater than" + min + ".");
	   else if(i >= max) 
		   System.out.println("Error!! Number must be less than " + max  + ".");
	   else
	       isValid = true;
	 }
	 return i;
}
public static int getInt(String cause,int min,int max){
	Scanner sc = new Scanner(System.in);
	int i=0;
	boolean isValid = false;
	while(isValid == false){
		i = getInt(sc,cause);
		if(i <=min)
			System.out.println("Error !! NUMber must be greater than "+ min + ".");
		else if(i >=max)
			System.out.println("Error!! NUmber must be less than "+ max + ".");
		else
			isValid = true;
			}
	return i;
	}
public static float getFloat(String cause){
	Scanner sc = new Scanner(System.in);
	float i=0;
	boolean isValid = false;
	while(isValid == false){
		System.out.println(cause);
		if(sc.hasNextFloat()){
			i= sc.nextFloat();
			isValid = true;
		}
		else {
			System.out.println("Invalid Float value !! Try Again");
		}
		sc.nextLine();
	}
	return i;
}
public static double getDouble(String cause){
	Scanner sc = new Scanner(System.in);
	double i=0;
	boolean isValid = false;
	while(isValid == false){
		System.out.println(cause);
		if(sc.hasNextDouble()){
			i = sc.nextDouble();
			isValid = true;
		}
		else{
			System.out.println("Invalid double value !! Try Again");
		}
		sc.nextLine();
	}
	return i;
}
}
