/*Client Program to implement the services of your choice
	@author Yogen Pradhan
	Done on 1st May 2022
	*/

package assignment.client;
import java.util.*;
import java.net.*;
import java.io.*;

public class Client {
            public static void main(String args[]) throws Exception {
            Socket socket= null;
            BufferedReader in = null;
            PrintWriter out = null;
            try {
            String host = "localhost";
            InetAddress serverSocket = InetAddress.getByName(host);
            socket = new Socket(serverSocket,3000);
	    System.out.println("Connected");
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
	     } catch (UnknownHostException e) {
                       e.printStackTrace();
                       System.exit(1);
               } catch (IOException e){
                       e.printStackTrace();
                       System.exit(1);
               } 
            BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	    String fromServer;
            String fromUser;
            try {  
	    while(true) {
		System.out.println("server: ");	
              while(!((fromServer = in.readLine()).equals("-EOF-")))   {
               System.out.println(fromServer);

               if(fromServer.contains("good bye")) {
                      out.close();
                      in.close();
                      stdIn.close();
                      socket.close();
                      System.exit(0);	
		}
            }
             
            fromUser = stdIn.readLine();
            if(fromUser != null) {
               System.out.println("Client : "+ fromUser);
               out.println(fromUser);
            }
         }
       } catch (IOException e) { 
       e.printStackTrace();
       } 
   }
}
